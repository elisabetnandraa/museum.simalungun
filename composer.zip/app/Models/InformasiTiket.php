<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InformasiTiket extends Model
{
    use HasFactory;

    protected $table = 'informasi_tikets';

    protected $fillable = [
        'harga',
        'deskripsi',
        'gambar',
    ];
}
